<?php error_reporting(0); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>The Wedding - Elinda & Riyan</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.svg"/>
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
        <!-- jQuery -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    </head>

    <body id="page-top" >

        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
            <a class="navbar-brand" href="#page-top"><img src="assets/img/navbar-logo.png" alt="..." /></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars ms-1"></i>
            </button>
            <div class="container">
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link" href="#date"><b>Save The Date</b></a></li>
                        <li class="nav-item"><a class="nav-link" href="#location"><b>Location</b></a></li>
                        <li class="nav-item"><a class="nav-link" href="#galery"><b>Our Story</b></a></li>
                        <li class="nav-item"><a class="nav-link" href="#info"><b>Info</b></a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Masthead-->
        <header class="masthead">
            <div class="container">
                <div class="masthead-heading text-uppercase">
                    <img src="assets/img/top-page/invited-to.png" class="img-fluid" width="420rem"/>
                </div>
                <a class="btn btn-info btn-xl text-uppercase" href="#date">Tell Me More</a>
            </div>
        </header>

        <!-- Date -->
        <section class="page-section" id="date">
            <div class="container">
                <div class="row text-center">
                    <div class="col-lg-2 col-md-2 col-sm-2 align-middle">
                        <img src="assets/img/top-page/top-flower-left.png" class="img-fluid" width="60%"/>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-8 align-middle">
                        <h2 class="section-heading text-uppercase">Save The Date</h2>
                        <h3 class="section-subheading text-muted">Acara Resepsi Pernikahan Elinda & Riyan</h3>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 align-middle">
                        <img src="assets/img/top-page/top-flower-right.png" class="img-fluid" width="60%"/>
                    </div>
                </div>
                <div class="row text-center align-middle">
                    <div class="col-lg-12 col-md-12 col-sm-12 mb-4 align-middle">
                        <center>
                            <img src="assets/img/top-page/invitation-letter.png" class="img-fluid" width="42%"/>
                        </center>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 mb-4 align-middle">
                        <img src="assets/img/top-page/date.png" class="img-fluid" width="48%"/>
                    </div>
                </div>
                <br>
                <div class="row text-center">
                    <div class="col-lg-2 col-md-2 col-sm-2 align-middle">
                        <img src="assets/img/top-page/bottom-left-flower.png" class="img-fluid" width="75%"/>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-8 align-middle">
                        <img src="assets/img/top-page/bottom-middle-flower.png" class="img-fluid" width="75%"/>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 align-middle">
                        <img src="assets/img/top-page/bottom-right-flower.png" class="img-fluid" width="75%"/>
                    </div>
                </div>
            </div>
        </section>

        <!-- Location -->
        <section class="page-section bg-light" id="location">
            <div class="container">
                <div class="row">
                    
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d989.5440774593945!2d109.03556682914243!3d-7.2207206692050585!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbcef9932e853310e!2zN8KwMTMnMTQuNiJTIDEwOcKwMDInMTAuMCJF!5e0!3m2!1sid!2sid!4v1644502359004!5m2!1sid!2sid" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                    <div class="col-lg-8 col-md-6 col-sm-12">
                        <div class="col-lg-12 text-center">
                            <br>
                            <h2 class="section-heading text-uppercase">Peta Lokasi</h2>
                            <h3 class="section-subheading text-muted">Acara Resepsi Pernikahan Elinda & Riyan</h3>
                        </div>
                        <div class="col-lg-12 text-center">
                            <h3 class="section-heading text-uppercase">Kediaman Mempelai Wanita</h3>
                            <h3 class="section-subheading text-muted">Jalan Assomad Benda 2 RT/RW 02/02, <br> Kec. Sirampog, Kab. Brebes, Prov. Jawa Tengah.</h3>
                        </div>
                    </div>
                </div>                      
            </div>
        </section>

        <!-- Galery Grid -->
        <section class="page-section" id="galery">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Our Story</h2>
                    <h3 class="section-subheading text-muted"> "Mungkin ketidaksempurnaan kita yang membuat kita begitu sempurna satu sama lain."</h3>
                </div>
                <div class="row text-center">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <img class="img-fluid" src="assets/img/galery/PT8A1324.png" alt="">
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <img class="img-fluid" src="assets/img/galery/PT8A1328.png" alt="">
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <img class="img-fluid" src="assets/img/galery/PT8A1331.png" alt="">
                    </div>
                </div>
            </div>
            <br><br>
        </section>

        <!-- Info -->
        <section class="page-section bg-light" id="info">
            <div class="row text-center">
                <h2 class="section-heading text-uppercase">Information</h2>
                <h3 class="section-subheading text-muted"> "Aku melihatmu dan melihat sisa hidupku di depan mataku." </h3>
            </div>
            <div class="container text-center">
                "Kepada tamu undangan yang berhalangan hadir namun ingin memberikan kado pernikahan kepada kami, <br> kami menyediakan akun wedding gift.. dan sebelumnya kami sangat berterima kasih, namun bagi kami doa restu yang lebih penting.."
            </div>
            <br>
            <div class="container text-center">
                <div class="col-lg-12">
                    <center>
                        <img src="assets/img/logos/logo-bri.png" class="img-fluid" width="20%">
                    </center>
                </div>
                <br>
                <div class="col-lg-12">
                    <center>
                        <div class="col-lg-6">
                            <input id="rekGift" type="text" class="form-control" value="587301033665534" readonly style="text-align: center;">
                        </div>
                    </center>
                </div>
                <br>
                <div class="col-lg-12">
                    <button id="copyBtn" class="btn btn-success btn-block">Copy Nomor Akun!</button>
                </div>
            </div>
        </section>

        <!-- Audio-->
        <section class="page-section">
            <div class="container">
                <center>
                    <audio controls autoplay id="playAudio">
                        <source name="audio" src="assets/audio/bg-music-2.ogg" type="audio/ogg">
                    </audio>
                    <script>
                        navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {

                        var x = document.getElementById("playAudio"); 
                        x.play();

                            // stop microphone stream acquired by getUserMedia
                            stream.getTracks().forEach(function (track) { track.stop(); });
                        });
                    </script>
                </center>        
            </div>
        </section>

        <!-- Modal -->
        <div class="portfolio-modal modal fade" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project details-->
                                    <div class="col-lg-12 col-md-12 col-lg-12">
                                        <center>
                                            <img class="img-fluid" src="assets/img/top-page/modal-couple.png" width="85%" alt="..." />
                                        </center>
                                    </div>
                                    <h3 class="text-uppercase">
                                        Kepada Yth,
                                    </h3>
                                    <h7 class="text-muted">
                                        Bapak/Ibu/Saudara/i
                                    </h7>
                                    <br>
                                    <h5 class="text-uppercase mt-2">
                                        <?php if ($_GET['to'] != '') {
                                            echo $_GET['to']
                                        };?>
                                    </h5>
                                    <br>
                                    <button class="btn btn-info btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                                        <i class="fas fa-heart me-1"></i>
                                        Buka Undangan
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer-->
        <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-start">The Wedding - Elinda & Riyan</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-lg-4 text-lg-end">Dasa Putra Media</div>
                </div>
            </div>
        </footer>

        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!--using sweetalert via CDN -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

        <script type="text/javascript">
            const copyBtn = document.getElementById('copyBtn')
            const copyText = document.getElementById('rekGift')
            
            copyBtn.onclick = () => {
                copyText.select();    // Selects the text inside the input
                document.execCommand('copy');    // Simply copies the selected text to clipboard 
                Swal.fire({         //displays a pop up with sweetalert
                    icon: 'success',
                    title: 'Rekening terkopi di Clipboard!',
                    showConfirmButton: false,
                    timer: 3000
                });
            }
        </script>

        <script type="text/javascript">
            $(window).on('load', function() {
                $('#myModal').modal('show');
            });
        </script>

    </body>
</html>
